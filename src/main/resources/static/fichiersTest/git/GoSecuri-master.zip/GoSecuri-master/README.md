Add a README file to test the trigger 2
